﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
 defined('_JEXEC') or die();

  $document =& JFactory::getDocument();
$document->addStyleSheet('modules/mod_jprogress/css/style.css');
$document->addStyleDeclaration($jprogressstyle);
if (version_compare(JVERSION, '3.0', '<'))
{
$document->addScript('http://ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js');
$document->addCustomTag( '<script type="text/javascript">jQuery.noConflict();</script>' );
}
else
{
JHtml::_('jquery.framework');
}
$document->addScript( 'modules/mod_jprogress/js/jprogress.js');
 ?>
<div id="jprogress">
<?php
for($i=0;$i<count($title);$i++)
{
echo '<table dir="'.$dir.'" ><tr><td><div class="name">'.$title[$i].'</div></td></tr>';
echo '<tr>';
if(trim($descs1)!='')
echo '<td width="'.$desc_width1.'">'.$desc1[$i].'</td>';
if(trim($descs2)!='')
echo '<td width="'.$desc_width2.'">'.$desc2[$i].'</td>';
if(trim($descs3)!='')
echo '<td width="'.$desc_width3.'">'.$desc3[$i].'</td>';
echo '<td><div class="'.$class.'"><span style="width:'.$value[$i].'">';
if($valueplace=='0')
echo '<div class="values">'.$value[$i].'</div></span></div></td></tr></table>';
else
echo '</span></div></td><td width="10%"><div class="values">'.$value[$i].'</div></td></tr></table>';

 }
?>
</div>
