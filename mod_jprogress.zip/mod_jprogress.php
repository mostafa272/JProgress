﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();
if(!defined('DS'))
{  define('DS',DIRECTORY_SEPARATOR);
}
// Include the helper class
require_once dirname(__FILE__) . DS . 'helper.php';
jimport( 'joomla.application.module.helper' );
$titles=htmlspecialchars($params->get('titles'));
$descs1=htmlspecialchars($params->get('desc1'));
$descs2=htmlspecialchars($params->get('desc2'));
$descs3=htmlspecialchars($params->get('desc3'));
$values=htmlspecialchars($params->get('values'));
$desc_width1=htmlspecialchars($params->get('desc1_width'));
$desc_width2=htmlspecialchars($params->get('desc2_width'));
$desc_width3=htmlspecialchars($params->get('desc3_width'));
$title=explode('@#',$titles);
$desc1=explode('@#',$descs1);
$desc2=explode('@#',$descs2);
$desc3=explode('@#',$descs3);
$value=explode('@#',$values);
$type=$params->get('type');
$color=$params->get('color');
$font=$params->get('titles_font');
$textcolor=$params->get('text_color','#FFFFFF');
$textshadow=$params->get('text_shadow','1px 1px #000000');
$margin_table=$params->get('margin_table','20px 0 20px 0');
$padding=$params->get('padding');
$height=$params->get('height','20px');
$item_font=$params->get('font');
$align=$params->get('textalign','left');
$dir=$params->get('direction','ltr');
$valueplace=$params->get('value_place','1');
$valuealign=$params->get('valuealign','right');
$animation=$params->get('animation');
if($type=="0")
{
 $class='meter progresscolor nostripes';
}
else{
 $class='meter progresscolor';
}
if($color=="blue")
{
$color1='#99CCFF';
$color2='#1975FF';
}
if($color=="red")
{
$color1='#f0a3a3';
$color2='#f42323';
}
if($color=="green")
{
$color1='#00FF33';
$color2='#009900';
}
if($color=="golden")
{
$color1='#FECF40';
$color2='#FFCC00';
}
if($color=="orange")
{
$color1='#f1a165';
$color2='#f36d0a';
}
if($color=="violet")
{
$color1='#F084EC';
$color2='#80017B';
}
if($color=="brown")
{
$color1='#AD5C33';
$color2='#663300';
}
if($color=="black")
{
$color1='#676767';
$color2='#000000';
}
$jprogressstyle='.progresscolor > span {
			background-color: '.$color1.';
			background-image: -moz-linear-gradient(top, '.$color1.','.$color2.');
			background-image: -webkit-gradient(linear,left top,left bottom,color-stop(0, '.$color1.'),color-stop(1,'.$color2.' ));
			background-image: -webkit-linear-gradient('.$color1.','.$color2.');
            background-image: -o-linear-gradient('.$color1.','.$color2.');
            background-image: linear-gradient('.$color1.','.$color2.');
		}';

$jprogressstyle=$jprogressstyle.'span div.values{
      text-align:'.$valuealign.';
     margin:0 10px 0 10px;
        }';

$jprogressstyle=$jprogressstyle.'#jprogress table{
              width: 100%;
              margin:'.$margin_table.';
              color:'.$textcolor.';
              text-shadow:'.$textshadow.';
}
#jprogress table td{
padding:'.$padding.';
margin:0;
height:'.$height.';
font:'.$item_font.';
text-align:'.$align.';
}
#jprogress div.name{
font:'.$font.';
}';
if($animation=="1"){
$jprogressstyle=$jprogressstyle.'.meter > span:after, .animate > span > span{
    -moz-animation: move 2s linear infinite;
    -webkit-animation: move 2s linear infinite;
    -o-animation: move 2s linear infinite; 
    animation: move 2s linear infinite;
 }';
}
// Display the template
require(JModuleHelper::getLayoutPath('mod_jprogress'));

?>